package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ClientEntity
import com.example.ui.theme.EditorialBackground
import com.example.ui.theme.EditorialOutlineVariant
import com.example.ui.theme.EditorialPrimary
import com.example.ui.theme.EditorialPrimaryDark
import com.example.ui.theme.EditorialPrimaryLight
import com.example.ui.theme.EditorialSurfaceVariant
import com.example.ui.theme.EditorialTextPrimary
import com.example.ui.theme.EditorialTextSecondary
import com.example.ui.theme.WhatsAppGreen
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ViewAndSendScreen(
    clients: List<ClientEntity>,
    allClientsCount: Int,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    offerTemplate: String,
    onOfferTemplateChange: (String) -> Unit,
    onDeleteClient: (ClientEntity) -> Unit
) {
    val context = LocalContext.current
    var clientToDelete by remember { mutableStateOf<ClientEntity?>(null) }
    var showBulkSendDialog by remember { mutableStateOf(false) }
    var bulkSendIndex by remember { mutableIntStateOf(0) }

    val presetOffers = listOf(
        "Special Offer for You! Get 20% OFF on your next visit.",
        "Namaste! Thank you for visiting us. Flat ₹200 OFF on your next booking.",
        "Weekend Special: 15% discount for our loyal clients!",
        "Festive Treat: Book now and get a free head massage / consultation!"
    )

    fun openWhatsApp(phone: String, text: String) {
        try {
            val encodedMessage = URLEncoder.encode(text, "UTF-8")
            val url = "https://wa.me/$phone?text=$encodedMessage"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open WhatsApp", Toast.LENGTH_SHORT).show()
        }
    }

    fun openSms(phone: String, text: String) {
        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:$phone")
                putExtra("sms_body", text)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open SMS app", Toast.LENGTH_SHORT).show()
        }
    }

    fun openCall(phone: String) {
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open dialer", Toast.LENGTH_SHORT).show()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Section 1: Broadcast Offer Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("send_offer_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, EditorialOutlineVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(EditorialPrimaryLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = null,
                                tint = EditorialPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "WhatsApp Broadcast & Offers",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 18.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = "Broadcast custom promotions to your clients",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = EditorialTextSecondary
                                )
                            )
                        }
                    }

                    // Offer Template TextArea
                    OutlinedTextField(
                        value = offerTemplate,
                        onValueChange = onOfferTemplateChange,
                        label = { Text("Offer Message Template") },
                        placeholder = { Text("Special Offer for You! Get 20% OFF on your next visit.") },
                        minLines = 3,
                        maxLines = 5,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EditorialPrimary,
                            focusedLabelColor = EditorialPrimary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("offer_template_input")
                    )

                    // Preset Chips
                    Text(
                        text = "Quick Offer Presets:",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Medium,
                            color = EditorialTextSecondary
                        )
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        presetOffers.forEach { preset ->
                            val isSelected = offerTemplate == preset
                            FilterChip(
                                selected = isSelected,
                                onClick = { onOfferTemplateChange(preset) },
                                label = {
                                    Text(
                                        text = preset.take(30) + if (preset.length > 30) "..." else "",
                                        fontSize = 12.sp
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EditorialPrimaryLight,
                                    selectedLabelColor = EditorialPrimary,
                                    containerColor = EditorialSurfaceVariant
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = if (isSelected) EditorialPrimary else EditorialOutlineVariant
                                ),
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }

                    // Send All Clients Button (WhatsApp Broadcast)
                    Button(
                        onClick = {
                            if (allClientsCount == 0) {
                                Toast.makeText(context, "Please add a client first!", Toast.LENGTH_SHORT).show()
                            } else {
                                bulkSendIndex = 0
                                showBulkSendDialog = true
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("send_whatsapp_all_button"),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = EditorialPrimary),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Send All Clients (WhatsApp)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Section 2: Saved Clients Header & Search
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Saved Clients",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    Surface(
                        shape = CircleShape,
                        color = EditorialPrimaryLight
                    ) {
                        Text(
                            text = "${clients.size} clients",
                            color = EditorialPrimary,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text("Search by name or number...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = EditorialTextSecondary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear search",
                                    tint = EditorialTextSecondary
                                )
                            }
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EditorialPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("client_search_input")
                )
            }
        }

        // Section 3: Client Cards or Empty State
        if (clients.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = EditorialSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, EditorialOutlineVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(EditorialPrimaryLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.People,
                                contentDescription = null,
                                tint = EditorialPrimary,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Text(
                            text = if (searchQuery.isNotEmpty()) "No clients match \"$searchQuery\"" else "No clients saved yet",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Text(
                            text = "Add client visits in the New Client tab to manage follow-ups.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = EditorialTextSecondary
                            ),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        } else {
            items(clients, key = { it.id }) { client ->
                EditorialClientCardItem(
                    client = client,
                    offerMessage = offerTemplate,
                    onWhatsAppClick = { openWhatsApp(client.phone, offerTemplate) },
                    onSmsClick = {
                        val thanksMsg = "Thanks for visiting us, ${client.name}! $offerTemplate"
                        openSms(client.phone, thanksMsg)
                    },
                    onCallClick = { openCall(client.phone) },
                    onDeleteClick = { clientToDelete = client }
                )
            }
        }
    }

    // Delete Confirmation Dialog
    if (clientToDelete != null) {
        val target = clientToDelete!!
        AlertDialog(
            onDismissRequest = { clientToDelete = null },
            shape = RoundedCornerShape(20.dp),
            title = { Text("Delete Client?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete ${target.name} (+${target.phone})?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteClient(target)
                        clientToDelete = null
                    },
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { clientToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Bulk WhatsApp Sender Wizard Dialog
    if (showBulkSendDialog && clients.isNotEmpty()) {
        val currentClient = clients.getOrNull(bulkSendIndex)
        AlertDialog(
            onDismissRequest = { showBulkSendDialog = false },
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = null,
                        tint = WhatsAppGreen
                    )
                    Text(
                        "WhatsApp Broadcast (${bulkSendIndex + 1}/${clients.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (currentClient != null) {
                        Text(
                            text = "Next Client: ${currentClient.name}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Text(
                            text = "Number: +${currentClient.phone}",
                            style = MaterialTheme.typography.bodyMedium.copy(color = EditorialTextSecondary)
                        )
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = EditorialSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, EditorialOutlineVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = offerTemplate,
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface),
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                        Text(
                            text = "Tap 'Send via WhatsApp' to message this client, then tap Next.",
                            style = MaterialTheme.typography.bodySmall.copy(color = EditorialTextSecondary)
                        )
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (currentClient != null) {
                        Button(
                            onClick = {
                                openWhatsApp(currentClient.phone, offerTemplate)
                            },
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen)
                        ) {
                            Text("Send via WhatsApp")
                        }

                        if (bulkSendIndex < clients.size - 1) {
                            Button(
                                onClick = { bulkSendIndex++ },
                                shape = CircleShape,
                                colors = ButtonDefaults.buttonColors(containerColor = EditorialPrimary)
                            ) {
                                Text("Next")
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Default.NavigateNext, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        } else {
                            Button(
                                onClick = {
                                    showBulkSendDialog = false
                                    Toast.makeText(context, "Broadcast completed for all clients!", Toast.LENGTH_SHORT).show()
                                },
                                shape = CircleShape,
                                colors = ButtonDefaults.buttonColors(containerColor = EditorialPrimary)
                            ) {
                                Text("Done")
                            }
                        }
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showBulkSendDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
fun EditorialClientCardItem(
    client: ClientEntity,
    offerMessage: String,
    onWhatsAppClick: () -> Unit,
    onSmsClick: () -> Unit,
    onCallClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }
    val formattedDate = remember(client.visitTimestamp) {
        dateFormat.format(Date(client.visitTimestamp))
    }

    val initials = remember(client.name) {
        val parts = client.name.trim().split("\\s+".toRegex())
        if (parts.size >= 2) {
            "${parts[0].firstOrNull()?.uppercase() ?: ""}${parts[1].firstOrNull()?.uppercase() ?: ""}"
        } else {
            client.name.take(2).uppercase()
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("client_card_${client.id}"),
        shape = RoundedCornerShape(16.dp),
        color = EditorialSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, EditorialOutlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Avatar circle with Editorial primary background
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(EditorialPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initials,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        )
                    }

                    Column {
                        Text(
                            text = client.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 15.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "+${client.phone}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = EditorialTextSecondary
                            )
                        )
                    }
                }

                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.testTag("client_delete_btn_${client.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete client",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                    )
                }
            }

            // Date & Service row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Visit: $formattedDate",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = EditorialTextSecondary,
                        fontSize = 11.sp
                    )
                )

                if (client.notes.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = EditorialPrimaryLight
                    ) {
                        Text(
                            text = client.notes,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = EditorialPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            // Action Buttons Row (WhatsApp, SMS, Call)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // WhatsApp Button
                Button(
                    onClick = onWhatsAppClick,
                    modifier = Modifier
                        .weight(1.3f)
                        .height(36.dp)
                        .testTag("client_wa_btn_${client.id}"),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "WhatsApp",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                // SMS Button
                OutlinedButton(
                    onClick = onSmsClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .testTag("client_sms_btn_${client.id}"),
                    shape = CircleShape,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = EditorialPrimary),
                    border = androidx.compose.foundation.BorderStroke(1.dp, EditorialPrimary),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Sms,
                        contentDescription = null,
                        tint = EditorialPrimary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "SMS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Call Button
                OutlinedButton(
                    onClick = onCallClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .testTag("client_call_btn_${client.id}"),
                    shape = CircleShape,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = EditorialTextSecondary),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = null,
                        tint = EditorialTextSecondary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Call",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
