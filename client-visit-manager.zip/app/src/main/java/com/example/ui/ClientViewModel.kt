package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ClientEntity
import com.example.data.ClientRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ScheduledThanks(
    val client: ClientEntity,
    val remainingMillis: Long
)

class ClientViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ClientRepository

    // User authentication state
    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _userEmail = MutableStateFlow("exonicsalon2@gmail.com")
    val userEmail: StateFlow<String> = _userEmail.asStateFlow()

    // Selected tab (0 = New Client, 1 = View & Send)
    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    // Search query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Offer template
    private val _offerTemplate = MutableStateFlow(
        "Special Offer for You! Get 20% OFF on your next visit."
    )
    val offerTemplate: StateFlow<String> = _offerTemplate.asStateFlow()

    // Recent action snackbar / alert message
    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    // All clients from Room Database
    val allClients: StateFlow<List<ClientEntity>>

    // Filtered clients based on search query
    val filteredClients: StateFlow<List<ClientEntity>>

    init {
        val database = AppDatabase.getInstance(application)
        repository = ClientRepository(database.clientDao())

        allClients = repository.allClients.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        filteredClients = combine(allClients, _searchQuery) { clients, query ->
            if (query.isBlank()) {
                clients
            } else {
                val trimmed = query.trim().lowercase()
                clients.filter {
                    it.name.lowercase().contains(trimmed) || it.phone.contains(trimmed)
                }
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun login(email: String) {
        if (email.isNotBlank()) {
            _userEmail.value = email.trim()
            _isLoggedIn.value = true
        }
    }

    fun logout() {
        _isLoggedIn.value = false
    }

    fun setTab(tabIndex: Int) {
        _selectedTab.value = tabIndex
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setOfferTemplate(template: String) {
        _offerTemplate.value = template
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun saveClient(name: String, phone: String, notes: String = ""): Boolean {
        val trimmedName = name.trim()
        val trimmedPhone = phone.trim()

        if (trimmedName.isEmpty() || trimmedPhone.isEmpty()) {
            _statusMessage.value = "Name aur Number dono bharein!"
            return false
        }

        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val newClient = ClientEntity(
                name = trimmedName,
                phone = formatPhoneNumber(trimmedPhone),
                notes = notes.trim(),
                visitTimestamp = now,
                autoThanksScheduledAt = now + 3600000L, // 1 hour delay
                isThanksSent = false
            )
            repository.insertClient(newClient)
            _statusMessage.value = "Client Saved! Auto Thanks SMS 1 ghante me schedule ho gaya."
        }
        return true
    }

    fun deleteClient(client: ClientEntity) {
        viewModelScope.launch {
            repository.deleteClient(client)
            _statusMessage.value = "${client.name} deleted."
        }
    }

    fun markThanksSent(clientId: Long) {
        viewModelScope.launch {
            repository.markThanksSent(clientId)
        }
    }

    companion object {
        fun formatPhoneNumber(input: String): String {
            val digitsOnly = input.replace(Regex("[^0-9]"), "")
            return when {
                digitsOnly.length == 10 -> "91$digitsOnly"
                digitsOnly.startsWith("0") && digitsOnly.length == 11 -> "91${digitsOnly.substring(1)}"
                else -> digitsOnly
            }
        }
    }
}
