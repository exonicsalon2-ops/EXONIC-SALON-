package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Editorial Aesthetic Color Palette
val EditorialPrimary = Color(0xFF6750A4)
val EditorialPrimaryDark = Color(0xFF5A4690)
val EditorialPrimaryLight = Color(0xFFEADDFF)
val EditorialOnPrimary = Color(0xFFFFFFFF)
val EditorialPrimaryContainer = Color(0xFFEADDFF)
val EditorialOnPrimaryContainer = Color(0xFF21005D)

val EditorialBackground = Color(0xFFFEF7FF)
val EditorialSurface = Color(0xFFFFFFFF)
val EditorialSurfaceVariant = Color(0xFFF3EDF7)
val EditorialNavContainer = Color(0xFFE7E0EC)

val EditorialTextPrimary = Color(0xFF1D1B20)
val EditorialTextSecondary = Color(0xFF49454F)
val EditorialOutline = Color(0xFFCAC4D0)
val EditorialOutlineVariant = Color(0xFFEADDFF)
val EditorialBorder = Color(0xFF79747E)

val EditorialAccent = Color(0xFF7D5260)
val EditorialAccentLight = Color(0xFFFFD8E4)

// Communication accents
val WhatsAppGreen = Color(0xFF25D366)
val WhatsAppDark = Color(0xFF128C7E)
val WhatsAppContainer = Color(0xFFDCF8C6)

val ErrorRed = Color(0xFFBA1A1A)
val OnErrorRed = Color(0xFFFFFFFF)
val ErrorContainer = Color(0xFFFFDAD6)
val OnErrorContainer = Color(0xFF410002)

// Dark Theme Variants
val EditorialDarkBackground = Color(0xFF141218)
val EditorialDarkSurface = Color(0xFF1D1B20)
val EditorialDarkSurfaceVariant = Color(0xFF49454F)
val EditorialDarkPrimary = Color(0xFFD0BCFF)
val EditorialDarkOnPrimary = Color(0xFF381E72)
val EditorialDarkPrimaryContainer = Color(0xFF4F378B)
val EditorialDarkTextPrimary = Color(0xFFE6E0E9)
val EditorialDarkTextSecondary = Color(0xFFCAC4D0)
val EditorialDarkOutline = Color(0xFF938F99)


