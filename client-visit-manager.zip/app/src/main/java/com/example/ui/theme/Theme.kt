package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = EditorialDarkPrimary,
    onPrimary = EditorialDarkOnPrimary,
    primaryContainer = EditorialDarkPrimaryContainer,
    onPrimaryContainer = EditorialPrimaryLight,
    secondary = EditorialAccentLight,
    onSecondary = Color(0xFF492532),
    secondaryContainer = Color(0xFF633B48),
    onSecondaryContainer = EditorialAccentLight,
    background = EditorialDarkBackground,
    onBackground = EditorialDarkTextPrimary,
    surface = EditorialDarkSurface,
    onSurface = EditorialDarkTextPrimary,
    surfaceVariant = EditorialDarkSurfaceVariant,
    onSurfaceVariant = EditorialDarkTextSecondary,
    outline = EditorialDarkOutline,
    outlineVariant = Color(0xFF49454F),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005)
)

private val LightColorScheme = lightColorScheme(
    primary = EditorialPrimary,
    onPrimary = EditorialOnPrimary,
    primaryContainer = EditorialPrimaryContainer,
    onPrimaryContainer = EditorialOnPrimaryContainer,
    secondary = EditorialAccent,
    onSecondary = Color.White,
    secondaryContainer = EditorialAccentLight,
    onSecondaryContainer = Color(0xFF31111D),
    background = EditorialBackground,
    onBackground = EditorialTextPrimary,
    surface = EditorialSurface,
    onSurface = EditorialTextPrimary,
    surfaceVariant = EditorialSurfaceVariant,
    onSurfaceVariant = EditorialTextSecondary,
    outline = EditorialOutline,
    outlineVariant = EditorialOutlineVariant,
    error = ErrorRed,
    onError = OnErrorRed,
    errorContainer = ErrorContainer,
    onErrorContainer = OnErrorContainer
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Keep dynamic color optional, default to our styled branding
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}


