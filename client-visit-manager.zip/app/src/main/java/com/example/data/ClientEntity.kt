package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "clients")
data class ClientEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val phone: String,
    val visitTimestamp: Long = System.currentTimeMillis(),
    val notes: String = "",
    val autoThanksScheduledAt: Long = System.currentTimeMillis() + (60 * 60 * 1000L), // 1 hour later
    val isThanksSent: Boolean = false
)
