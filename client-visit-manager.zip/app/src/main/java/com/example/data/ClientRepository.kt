package com.example.data

import kotlinx.coroutines.flow.Flow

class ClientRepository(private val clientDao: ClientDao) {
    val allClients: Flow<List<ClientEntity>> = clientDao.getAllClients()

    suspend fun insertClient(client: ClientEntity): Long {
        return clientDao.insertClient(client)
    }

    suspend fun updateClient(client: ClientEntity) {
        clientDao.updateClient(client)
    }

    suspend fun deleteClient(client: ClientEntity) {
        clientDao.deleteClient(client)
    }

    suspend fun deleteClientById(id: Long) {
        clientDao.deleteClientById(id)
    }

    suspend fun markThanksSent(id: Long) {
        clientDao.markThanksSent(id)
    }

    fun searchClients(query: String): Flow<List<ClientEntity>> {
        return clientDao.searchClients(query)
    }
}
